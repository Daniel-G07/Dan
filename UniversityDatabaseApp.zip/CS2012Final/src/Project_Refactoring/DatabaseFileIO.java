package Project_Refactoring;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class DatabaseFileIO {

	public DatabaseFileIO () {

	}
	
	//used in an alternate way
	public static void printFile() throws IOException {
		Scanner input =  new Scanner(System.in);

		FileWriter fw = new FileWriter("database_files/database.csv", true);
		BufferedWriter keep = new BufferedWriter(fw);
		PrintWriter pw = new PrintWriter(keep);
		Scanner in = new Scanner(System.in);
		Scanner in1 = new Scanner(System.in);
		Scanner in2 = new Scanner(System.in);


		try{
			String personType = input.nextLine();

			if(personType.equalsIgnoreCase("Student")) {

				String fname = input.nextLine();
				String lname = input.nextLine();
				String email = input.nextLine();
				String classStanding = input.nextLine();
				double GPA = input.nextDouble();
				input.nextLine();
				int streetNumber = in.nextInt();
				String streetName = in1.nextLine();
				int apartmentNumber = in.nextInt();
				String city = in1.nextLine();
				String state = in1.nextLine();
				int zipCode = in1.nextInt();
				pw.println("Student," + fname + "," + lname + "," + email + "," + classStanding + "," + GPA);
				pw.println("Address," + streetNumber + "," + streetName + "," + apartmentNumber + "," + city + "," + state + "," + zipCode);
				int numOfPhones = in1.nextInt();
				String phoneType = "";
				int areaCode = 0;
				int prefix = 0;
				int suffix = 0;
				for(int i = 0; i < numOfPhones; i++) {
					phoneType = in2.nextLine();
					areaCode = in1.nextInt();
					prefix = in1.nextInt();
					suffix = in1.nextInt();

					pw.println("Phone(s)," + phoneType + "," + areaCode + "-" + prefix + "-" + suffix);
				}

			}
			else if(personType.equalsIgnoreCase("Faculty")) {
				Scanner in3 = new Scanner(System.in);
				Scanner in4 = new Scanner(System.in);
				Scanner in5 = new Scanner(System.in);
				Scanner in0 = new Scanner(System.in);
				Scanner in01 = new Scanner(System.in);
				Scanner inNew = new Scanner(System.in);

				String name = input.nextLine();
				String[] nameParts = name.split(" ");
				String firstName = nameParts[0];
				String lastName = nameParts[1];
				String email = in3.nextLine();
				int streetNumber = in3.nextInt();
				String streetName = in4.nextLine();
				int apartmentNumber = in4.nextInt();
				String city = in5.nextLine();
				String state = in5.nextLine();
				int zipCode = in5.nextInt();

				String buildingName = in0.nextLine();
				int officeNumber = in0.nextInt();
				double salary = in0.nextDouble();
				int startHour = in0.nextInt();
				int finishHour = in0.nextInt();
				String rank = in01.nextLine();

				pw.println("Faculty," + firstName + "," + lastName + "," + email + "," + buildingName + "," + officeNumber + "," + 
						salary + "," + startHour + "," + finishHour + "," + rank);
				pw.println("Address," + streetNumber + "," + streetName + "," + apartmentNumber + "," + city + "," 
						+ state + "," + zipCode);

				int numOfPhones = in3.nextInt();
				String phoneType = "";
				int areaCode = 0;
				int prefix = 0;
				int suffix = 0;

				for(int i = 0; i < numOfPhones; i++) {
					phoneType = inNew.nextLine();
					areaCode = in5.nextInt();
					prefix = in5.nextInt();
					suffix = in5.nextInt();
					pw.print("Phone(s)," + phoneType + "," + areaCode + "-" + prefix + "-" + suffix);
				}


			}
			else if(personType.equalsIgnoreCase("Staff")) {
				Scanner in3 = new Scanner(System.in);
				Scanner in4 = new Scanner(System.in);
				Scanner in5 = new Scanner(System.in);
				Scanner in0 = new Scanner(System.in);
				Scanner in01 = new Scanner(System.in);
				Scanner inNew = new Scanner(System.in);

				String name = input.nextLine();
				String[] nameParts = name.split(" ");
				String firstName = nameParts[0];
				String lastName = nameParts[1];
				String email = in3.nextLine();
				int streetNumber = in3.nextInt();
				String streetName = in4.nextLine();
				int apartmentNumber = in4.nextInt();
				String city = in5.nextLine();
				String state = in5.nextLine();
				int zipCode = in5.nextInt();

				String buildingName = in0.nextLine();
				int officeNumber = in0.nextInt();
				Double salary = in0.nextDouble();
				String jobTitle = in01.nextLine();

				pw.println("Staff," + firstName + "," + lastName + "," + email + "," + buildingName + "," + officeNumber + "," + 
						salary + "," + jobTitle);
				pw.println("Address," + streetNumber + "," + streetName + "," + apartmentNumber + "," + city + "," 
						+ state + "," + zipCode);

				int numOfPhones = in5.nextInt();
				String phoneType = "";
				int areaCode = 0;
				int prefix = 0;
				int suffix = 0;

				for(int i = 0; i < numOfPhones; i++) {
					phoneType = inNew.nextLine();
					areaCode = in5.nextInt();
					prefix = in5.nextInt();
					suffix = in5.nextInt();

					pw.println("Phone(s)," + phoneType + "," + areaCode + "-" + prefix + "-" + suffix);
				}

			}
			pw.close();
		}catch (Exception e){
			System.err.println("Error: " + e.getMessage());
		}
	}

	public static Database Read(File inFile) {
		Database data = new Database();
		
		try {
			Scanner reader = new Scanner(inFile);
			ArrayList<PhoneNumber> phoneNums = new ArrayList<PhoneNumber>();

			while(reader.hasNextLine()) {
				String nextLine = reader.nextLine();

				String[] parts = nextLine.split(",");
				String type = parts[0];

				if(type.equalsIgnoreCase("Student")) {
					Person p = new Student(parts[1],parts[2],parts[3],null,null,parts[4],Double.parseDouble(parts[5]));
					data.add(p);
					phoneNums = new ArrayList<PhoneNumber>();
				}
				else if(type.equalsIgnoreCase("Faculty")) {
					Person p = new Faculty(parts[1],parts[2],parts[3],null,null,parts[4], Double.parseDouble(parts[5]), parts[6], parts[7]);

					data.add(p);
					phoneNums = new ArrayList<PhoneNumber>();
				}
				else if(type.equalsIgnoreCase("Staff")) {
					Person p = new Staff(parts[1],parts[2],parts[3],null,null,parts[4], Double.parseDouble(parts[5]), parts[6]);
					data.add(p);
					phoneNums = new ArrayList<PhoneNumber>();
				}
				else if(type.equalsIgnoreCase("Phone")) {
					String phoneNum = parts[2];
					String[] phoneTokens = phoneNum.split("-");
					PhoneNumber pn = new PhoneNumber(parts[1], Integer.parseInt(phoneTokens[0]), Integer.parseInt(phoneTokens[1]), Integer.parseInt(phoneTokens[2]));
					phoneNums.add(pn);
				}
				else if(type.equalsIgnoreCase("Address")) {
					Address a = null;
					if(parts.length == 6) {
						
						a = new Address(Integer.parseInt(parts[1]), parts[2], parts[3], parts[4], Integer.parseInt(parts[5]));
					}
					else {
						
						a = new Address(Integer.parseInt(parts[1]),parts[2],parts[3], parts[4], parts[5], Integer.parseInt(parts[6]));
					}
					data.get(data.size() - 1).setAddress(a);
				}
				data.get(data.size() - 1).setPhoneNumbers(phoneNums);

			}
		}
		catch(FileNotFoundException e) {
			System.exit(0);
		}
		return data;
	}
	

}