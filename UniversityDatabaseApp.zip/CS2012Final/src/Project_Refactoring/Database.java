package Project_Refactoring;

import java.util.ArrayList;


public class Database extends ArrayList<Person> {
	
	public Database () {

		
	}

	@Override
	public String toString () {
		return super.toString();
	}
	
	public void printEmployees () {
		for (int i = 0; i < super.size(); i ++) {
			Person e = super.get(i);
		if (e instanceof Employee) {
			Employee em = (Employee)e;
			System.out.println(em.toString());
			}
		}
	}
	
	
	public void printStudents () {
		for (int i = 0; i < super.size(); i ++) {
			Person s = super.get(i);
		if (s instanceof Student) {
			Student st = (Student)s;
			System.out.println(st.toString());
			}
		}
	}
	
	public void printFaculty () {
		for (int i = 0; i < super.size(); i ++) {
			Person f = super.get(i);
		if (f instanceof Faculty) {
			Faculty fa = (Faculty)f;
			System.out.println(fa.toString());
			}
		}
	}
	
	public void printStaff () {
		for (int i = 0; i < super.size(); i ++) {
			Person staf = super.get(i);
		if (staf instanceof Staff) {
			Staff staff = (Staff)staf;
			System.out.println(staff.toString());
			}
		}
	}
	
	public int getNumberOfPeople () {
		int total = 0;
		for (int i = 0; i < super.size(); i++) {
			Person p = super.get(i);
		if (p instanceof Person) {
			total++;
			}
		}
		return total;
	}
	
	public int getNumberOfStudents () {
		int total = 0;
		for (int i = 0; i < super.size(); i++) {
			Person s = super.get(i);
		if (s instanceof Student) {
			total++;
			}
		}
		return total;
	}
	
	public int getNumberOfEmployees () {
		int total = 0;
		for (int i = 0; i < super.size(); i++) {
			Person s = super.get(i);
		if (s instanceof Employee) {
			total++;
			}
		}
		return total;
	}
	
	public int getNumberOfStaff () {
		int total = 0;
		for (int i = 0; i < super.size(); i++) {
			Person s = super.get(i);
		if (s instanceof Staff) {
			total++;
			}
		}
		return total;
	}
	
	public int getNumberOfFaculty () {
		int total = 0;
		for (int i = 0; i < super.size(); i++) {
			Person s = super.get(i);
		if (s instanceof Faculty) {
			total++;
			}
		}
		return total;
	}
	
	
	public int getNumberOfStudentsByClassSttanding (String classStanding) {
		int total = 0;
		for (int i = 0; i < super.size(); i ++) {
			Person p = super.get(i);
			if (p instanceof Student) {
				if (classStanding.equalsIgnoreCase(classStanding)) {
					total++;
				}
				
			}
		}
		return total;
	}
	
	public void printStudentsGreaterThanOrEqualToGPA(double gpa) {
		for (int i = 0; i < super.size(); i ++) {
			Person s = super.get(i);
		if (s instanceof Student) {
			Student st = (Student)s;
			if (st.getGpa() >= gpa) {
				System.out.println(st.toString());
				}
			
			}
		}
	}
	
	public void printStudentsLessThanOrEqualToGPA(double gpa) {
		for (int i = 0; i < super.size(); i ++) {
			Person s = super.get(i);
		if (s instanceof Student) {
			Student st = (Student)s;
			if (st.getGpa() <= gpa) {
				System.out.println(st.toString());
				}
			
			}
		}
	}
	
	
}
