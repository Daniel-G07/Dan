package Project_Refactoring;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class TopPanel extends Pane {
	
	public TopPanel() {
		ImageView not = new ImageView(new Image("Pics/not3.jpg"));
		not.setTranslateX(335);
		not.setTranslateY(15);
		
		Rectangle top = new Rectangle(0, 0, 375, 50);
		top.setFill(Color.rgb(242, 242, 242));
		top.setStroke(Color.rgb(217, 217, 217));
		 Text text1 = new Text(120, 30, "CAL STATE LA");
			Font font1 = Font.font("Courier", FontWeight.BOLD, 
					FontPosture.ITALIC, 20);
			text1.setFont(font1);
			text1.setFill(Color.BLACK);
		
		super.getChildren().addAll(top, text1, not);
	}
	
}
