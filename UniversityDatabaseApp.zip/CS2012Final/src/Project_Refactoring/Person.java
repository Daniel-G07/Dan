package Project_Refactoring;

import java.util.ArrayList;

public class Person {
	private String firstName;
	private String lastName;
	private String emailAddress;
	private Address address;
	private ArrayList <PhoneNumber> phoneNumbers;
	
	public Person () {
		this.firstName = "";
		this.lastName = "";
		this.emailAddress = "";
		this.address = null;
		this.phoneNumbers = new ArrayList<>();
		
	}
	
	public Person (String firstName, String lastName, String emailAddress, Address address,
			ArrayList<PhoneNumber>phoneNumbers) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailAddress = emailAddress;
		this.address = address;
		this.phoneNumbers = phoneNumbers;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public String getEmailAddress() {
		return this.emailAddress;
	}

	public Address getAddress() {
		return this.address;
	}
	public Address setAddress(Address a) {
		this.address = a;
		return a;
	}

	public ArrayList<PhoneNumber> getPhoneNumbers() {
		return this.phoneNumbers;
	}
	
	public ArrayList<PhoneNumber> setPhoneNumbers(ArrayList<PhoneNumber> p) {
		this.phoneNumbers = p;
		return p;
	}
	
	
	public String toString() {
		String result = "";
		result += "\nName:\t\t  " + getFirstName() + " " + getLastName() + "\nEmail:\t\t  " 
				+ getEmailAddress() +"\nAddress:\t  " + getAddress() + "\nPhone Number(s):  ";
				for (int i = 0; i < phoneNumbers.size(); i ++) {
					result += phoneNumbers.get(i)+ " ";
				}
		return result;
	}
	
	public boolean equals(Object o) { 
		if (!(o instanceof Person)) {
		return false;
		}
		else {
			Person eq = (Person)o;
			return this.firstName.equalsIgnoreCase(eq.firstName)&&
					this.lastName.equalsIgnoreCase(eq.lastName) && 
					this.emailAddress.equalsIgnoreCase(eq.emailAddress)&&
					this.phoneNumbers.equals(eq.phoneNumbers);
		}
	}
 
	
	
}