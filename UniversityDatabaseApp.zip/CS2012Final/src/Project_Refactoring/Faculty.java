package Project_Refactoring;

import java.util.ArrayList;

public class Faculty extends Employee {
	private String officeHours;
	private String rank;
	
	public Faculty (String firstName, String lastName, String emailAddress, Address address,
			ArrayList<PhoneNumber> phoneNumbers, String officeLocation,double salary, String officeHours, String rank) {
		super(firstName, lastName, emailAddress, address, phoneNumbers,officeLocation,salary);
		this.officeHours = officeHours;
		this.rank = rank;
	}

	public String getOfficeHours() {
		return officeHours;
	}
	
	public String getRank() {
		return rank;
	}
	
	@Override
	public String toString() {
			String result = "";
			result += super.toString() + "\nOffice Hours:\t  " + this.officeHours + "\nRank:\t\t  " + this.rank+ "\n" + 
					"---------------------------------------------------------------\n";
			return result ;
	}
	
	public boolean equals(Object o) { 
		if (!(o instanceof Faculty)) {
		return false;
		}
		else {
			Faculty eq = (Faculty)o;
			return super.equals(o) && this.officeHours.equalsIgnoreCase(eq.officeHours) && 
					this.rank.equalsIgnoreCase(eq.rank);
		}
	}

	
	
}
