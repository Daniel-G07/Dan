package Project_Refactoring;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ButtonPanel extends HBox {
	private CenterPane centerPane;
	
	public ButtonPanel (CenterPane centerPane,Stage primaryStage) {
		this.centerPane = centerPane;
		super.getChildren().addAll(printList(), printDelete(), printHome(primaryStage), printAdd(), printSearch());
		super.setAlignment(Pos.CENTER);
		super.setPadding(new Insets(10));
		super.setSpacing(40);
		super.setStyle("-fx-background-color: rgb(242, 242, 242); -fx-border-color: rgb(217, 217, 217) rgb(242, 242, 242) rgb(242, 242, 242) rgb(242, 242, 242);");
		
	}
	
	private Button printHome(Stage primaryStage) {
		//Button home = new Button();
		ImageView h = new ImageView(new Image("Pics/home.jpg"));
		Button home = new Button("", h);
		//home.setTranslateY(660);
		//home.setTranslateX(170);
		home.setOnAction(e-> 
			this.centerPane.setHomeView(primaryStage));
		return home;
	}
	
	public Button printAdd() {
		Button plus = new Button("+");
		//plus.setTranslateY(660);
		//plus.setTranslateX(230);
		plus.setOnAction(e -> this.centerPane.setAddChoiceView());
		return plus;
	}
	
	public Button printDelete () {
		Button minus = new Button("-");
		//minus.setTranslateY(660);
		//minus.setTranslateX(110);
		minus.setOnAction(e-> this.centerPane.setDeleteView());
		return minus;
	}
	
	public Button printSearch() {
		ImageView s = new ImageView(new Image("Pics/search3.png"));
		Button search = new Button("", s);
		//search.setTranslateY(660);
		//search.setTranslateX(295);
		search.setOnAction(e -> this.centerPane.setSearchView());
		return search;
	}
	
	public Button  printList () {
		Button button = new Button();
		//this.list = button;
		ImageView l = new ImageView(new Image("Pics/list.png"));
		button = new Button("", l);
		//button.setTranslateY(660);
		//button.setTranslateX(40);
		//button.setOnAction(e -> window.setScene(lists));
		button.setOnAction(e -> this.centerPane.setListView());
		return button;
	}

}
