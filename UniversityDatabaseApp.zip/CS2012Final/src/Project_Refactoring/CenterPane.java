package Project_Refactoring;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class CenterPane extends Pane {

	private TextField tfFirstName = new TextField();
	private TextField tfLastName = new TextField();
	private TextField tfEmail = new TextField();
	private TextField tfAddress = new TextField();
	private TextField tfAppt = new TextField();
	private TextField tfCity = new TextField();
	private TextField tfState = new TextField();
	private TextField tfZCode = new TextField();
	private TextField tfPhone = new TextField();
	private TextField tfPType = new TextField();
	private TextField tfOLocation = new TextField();
	private TextField tfSalary= new TextField();
	private TextField tfOHours = new TextField();
	private TextField tfClassStanding = new TextField();
	private TextField tfRank = new TextField();
	private TextField tfJTitle = new TextField();
	private TextField tfGpa = new TextField();
	private TextField tfSearch = new TextField();
	private Database db;
	File choosenFile = new File("");

	public CenterPane(Stage primaryStage) {
		this.setHomeView( primaryStage);
	}

	public void setHomeView(Stage primaryStage) {
		super.getChildren().clear();
		ImageView log = new ImageView(new Image("Pics/csulalogo.jpg"));
		log.setTranslateX(40);
		log.setTranslateY(160);
		
		Button chooseFile = new Button("Choose File");
		chooseFile.setTranslateX(150);
		chooseFile.setTranslateY(500);
		FileChooser choice = new FileChooser();
		choice.setInitialDirectory(new File("database_files/"));
		
		try {
			
			chooseFile.setOnAction(e -> {
			choosenFile = choice.showOpenDialog(primaryStage);
			setPath(choosenFile.getPath());
			setListView();
			});
		}catch (Exception e) {
			errorMessage();
		}
		
		super.setStyle("-fx-background-color: white");
		super.getChildren().addAll(log, chooseFile);
	}
	
	public void setPath (String path) {
		File inFile = new File(path);
		 db = DatabaseFileIO.Read(inFile);
	}

	public void setAddChoiceView() {
		super.getChildren().clear();
		ImageView p = new ImageView(new Image("Pics/filter4.png"));
		p.setTranslateX(20);
		p.setTranslateY(250);
		Text text2 = new Text(20, 100, "Add People");
		Font font2 = Font.font("Courier", FontWeight.BOLD, 
				FontPosture.ITALIC, 20);
		text2.setFont(font2);
		text2.setFill(Color.BLACK);
		Text text3 = new Text(45, 250, "Filter");
		Font font3 = Font.font("Courier", FontWeight.BOLD, 
				FontPosture.ITALIC, 20);
		text3.setFont(font2);
		text3.setFill(Color.BLACK);

		RadioButton addStudent = new RadioButton("Student");
		addStudent.setOnAction(e -> this.showAddStudentView());


		RadioButton addFaculty = new RadioButton("Faculty");
		addFaculty.setOnAction(e -> this.showAddFacultyView());

		RadioButton addStaff = new RadioButton("Staff");
		addStaff.setOnAction(e -> this.showAddStaffView());

		ToggleGroup tg = new ToggleGroup();
		addStudent.setToggleGroup(tg);
		addFaculty.setToggleGroup(tg);
		addStaff.setToggleGroup(tg);

		Pane r = new Pane(); 
		VBox paneForCheckBoxes = new VBox(20);
		paneForCheckBoxes.setPadding(new Insets(5, 5, 5, 5)); 
		paneForCheckBoxes.getChildren().addAll(addStudent,addFaculty, addStaff);
		r.getChildren().add(paneForCheckBoxes);
		r.setTranslateX(250);
		r.setTranslateY(270);



		super.getChildren().add(p);
		super.getChildren().addAll(text2, text3, r);
	}

	public void showAddFacultyView() {
		
		super.getChildren().clear();
		
		GridPane gp = new GridPane();
		gp.setAlignment(Pos.CENTER);
		gp.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		gp.setHgap(10);
		gp.setVgap(10);
		gp.add(new Label("First Name: "), 0, 0);
		gp.add(tfFirstName, 1, 0);
		gp.add(new Label("Last Name: "), 0, 1);
		gp.add(tfLastName, 1, 1);
		gp.add(new Label("Email: "), 0, 2);
		gp.add(tfEmail, 1, 2);
		gp.add(new Label("Address: "), 0 , 3);
		gp.add(tfAddress, 1, 3);
		gp.add(new Label("City: "), 0 , 4);
		gp.add(tfCity, 1, 4);
		gp.add(new Label("State: "), 0 , 5);
		gp.add(tfState, 1, 5);
		gp.add(new Label("Zip Code: "), 0 , 6);
		gp.add(tfZCode, 1, 6);
		gp.add(new Label("Appt. #: "), 0 , 7);
		gp.add(tfAppt, 1, 7);
		gp.add(new Label("Phone type: "), 0 , 8);
		gp.add(tfPType, 1, 8);
		gp.add(new Label("Phone#: "), 0 , 9);
		gp.add(tfPhone, 1, 9);
		gp.add(new Label("Office Location: "), 0 , 10);
		gp.add(tfOLocation, 1, 10);
		gp.add(new Label("Salary: "), 0 , 11);
		gp.add(tfSalary, 1, 11);
		gp.add(new Label("Office Hours: "), 0 , 12);
		gp.add(tfOHours, 1, 12);
		gp.add(new Label("Rank: "), 0 , 13);
		gp.add(tfRank, 1, 13);

		Button btAdd = new Button("Add Faculty");
		btAdd.setOnAction(e -> { 
			addFaculty();
			setAddChoiceView();
		});
	    gp.add(btAdd, 1, 14);
	    GridPane.setHalignment(btAdd, HPos.RIGHT);
		super.getChildren().add(gp);
	}
	
	
	public void showAddStudentView() {
		super.getChildren().clear();
		
		GridPane gp = new GridPane();
		gp.setAlignment(Pos.CENTER);
		gp.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		gp.setHgap(10);
		gp.setVgap(10);
		gp.add(new Label("First Name: "), 0, 0);
		gp.add(tfFirstName, 1, 0);
		gp.add(new Label("Last Name: "), 0, 1);
		gp.add(tfLastName, 1, 1);
		gp.add(new Label("Email: "), 0, 2);
		gp.add(tfEmail, 1, 2);
		gp.add(new Label("Address: "), 0 , 3);
		gp.add(tfAddress, 1, 3);
		gp.add(new Label("City: "), 0 , 4);
		gp.add(tfCity, 1, 4);
		gp.add(new Label("State: "), 0 , 5);
		gp.add(tfState, 1, 5);
		gp.add(new Label("Zip Code: "), 0 , 6);
		gp.add(tfZCode, 1, 6);
		gp.add(new Label("Appt. #: "), 0 , 7);
		gp.add(tfAppt, 1, 7);
		gp.add(new Label("Phone type: "), 0 , 8);
		gp.add(tfPType, 1, 8);
		gp.add(new Label("Phone#: "), 0 , 9);
		gp.add(tfPhone, 1, 9);
		gp.add(new Label("Class Standing: "), 0 , 10);
		gp.add(tfClassStanding, 1, 10);
		gp.add(new Label("GPA: "), 0 , 11);
		gp.add(tfGpa, 1, 11);

		Button btAdd = new Button("Add Student");
		
		btAdd.setOnAction(e -> { 
				addStudent();
				setAddChoiceView();
		});
	    gp.add(btAdd, 1, 12);
	    GridPane.setHalignment(btAdd, HPos.RIGHT);
		super.getChildren().add(gp);
	}
	
	public void showAddStaffView() {
		super.getChildren().clear();
		
		GridPane gp = new GridPane();
		gp.setAlignment(Pos.CENTER);
		gp.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		gp.setHgap(10);
		gp.setVgap(10);
		gp.add(new Label("First Name: "), 0, 0);
		gp.add(tfFirstName, 1, 0);
		gp.add(new Label("Last Name: "), 0, 1);
		gp.add(tfLastName, 1, 1);
		gp.add(new Label("Email: "), 0, 2);
		gp.add(tfEmail, 1, 2);
		gp.add(new Label("Address: "), 0 , 3);
		gp.add(tfAddress, 1, 3);
		gp.add(new Label("City: "), 0 , 4);
		gp.add(tfCity, 1, 4);
		gp.add(new Label("State: "), 0 , 5);
		gp.add(tfState, 1, 5);
		gp.add(new Label("Zip Code: "), 0 , 6);
		gp.add(tfZCode, 1, 6);
		gp.add(new Label("Appt. #: "), 0 , 7);
		gp.add(tfAppt, 1, 7);
		gp.add(new Label("Phone type: "), 0 , 8);
		gp.add(tfPType, 1, 8);
		gp.add(new Label("Phone#: "), 0 , 9);
		gp.add(tfPhone, 1, 9);
		gp.add(new Label("Office Location: "), 0 , 10);
		gp.add(tfOLocation, 1, 10);
		gp.add(new Label("Salary: "), 0 , 11);
		gp.add(tfSalary, 1, 11);
		gp.add(new Label("Job Title: "), 0 , 12);
		gp.add(tfJTitle, 1, 12);

		Button btAdd = new Button("Add Staff");
		btAdd.setOnAction(e -> { 
			addStaff();
			setAddChoiceView();
		});
	    gp.add(btAdd, 1, 13);
	    GridPane.setHalignment(btAdd, HPos.RIGHT);
		super.getChildren().add(gp);
	}
	
	public void setSearchView () {
		super.getChildren().clear();
		GridPane gp = new GridPane();
		gp.setAlignment(Pos.CENTER);
		gp.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		gp.setHgap(10);
		gp.setVgap(10);
		gp.add(new Label("Search: "), 4, 10);
		gp.add(tfSearch, 5, 10);
		ImageView log = new ImageView(new Image("Pics/searchpic.jpg"));
		log.setTranslateX(60);
		log.setTranslateY(200);
		Button btsearch = new Button("Enter");
		btsearch.setOnAction(e -> {
			try {
			String[] search = tfSearch.getText().split(" ");
			String search2 = tfSearch.getText();
		    String n = "";
			for (int i = 0; i < db.size(); i++) {
				if (search[0].equalsIgnoreCase(db.get(i).getFirstName()) || search[1].equalsIgnoreCase(db.get(i).getLastName())) {
					n += db.get(i);
				}
			}
			searchResults(n);
			}catch(Exception E) {
				errorMessage();
			}
		} );
	    gp.add(btsearch, 5, 11);
	    GridPane.setHalignment(btsearch, HPos.RIGHT);
		super.setStyle("-fx-background-color: white");
		super.getChildren().addAll(log, gp);
	}
	
	public void searchResults (String s) {
		super.getChildren().clear();
		TextArea te = new TextArea();
		te.setText(s);
		te.setEditable(false);
		ScrollPane sp = new ScrollPane(te);
		te.setPrefHeight(605);
		super.getChildren().addAll(sp);
	}
	
	public void setListView () {
		super.getChildren().clear();
		String s = "";
		TextArea te = new TextArea();
		try {
			for (int i = 0; i < db.size(); i++) {
					s += db.get(i);
			}
			te.setText(s);	
		}catch(Exception e) {
			errorMessage();
		}
		
		te.setEditable(false);
		ScrollPane sp = new ScrollPane(te);
		te.setPrefHeight(555);
		ComboBox<String> choice = new ComboBox();
		choice.setPrefWidth(80);
		choice.setPromptText("Filter");
		String[] choices = {"All Faculty", "All Staff", "All Students"};
		ObservableList<String> menu = FXCollections.observableArrayList(choices);
		choice.setTranslateY(565);
		choice.setTranslateX(10);
		choice.getItems().addAll(menu);
		choice.setOnAction(e -> {
			
			if (choice.getValue().toString().equalsIgnoreCase("All Faculty")) {
				String fa = "";
				try {
					for (int i = 0; i < db.size(); i++) {
						if (db.get(i) instanceof Faculty) {
							fa += db.get(i);
						}
					}
					te.setText(fa);
					
					
				}catch(Exception ex) {
					errorMessage();
				}
			}
			
			else if (choice.getValue().toString().equalsIgnoreCase("All Staff")) {
				String sta = "";
				try {
					for (int i = 0; i < db.size(); i++) {
						if (db.get(i) instanceof Staff) {
							sta += db.get(i);
						}
					}
					te.setText(sta);
					
					
				}catch(Exception ex) {
					errorMessage();
				}
			}
			
			else if (choice.getValue().toString().equalsIgnoreCase("All Students")) {
				String st = "";
				try {
					for (int i = 0; i < db.size(); i++) {
						if (db.get(i) instanceof Student) {
							st += db.get(i);
						}
					}
					te.setText(st);
					
					
				}catch(Exception ex) {
					errorMessage();
				}
			}
			
		});
		
		GridPane gp = new GridPane();
		TextField gpa = new TextField();
		gp.setAlignment(Pos.CENTER);
		gp.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		gp.setHgap(10);
		gp.setVgap(10);
		gp.add(new Label("GPA:"), 10, 55);
		RadioButton greater = new RadioButton("+");
		greater.setTranslateX(250);
		greater.setTranslateY(565);
		RadioButton less = new RadioButton("-");
		less.setTranslateX(250);
		less.setTranslateY(585);
		gp.add(gpa, 11, 55);
		gpa.setPrefWidth(80);
		super.getChildren().addAll(sp, choice);
		
	}
	
	public void setDeleteView() {
		super.getChildren().clear();
		GridPane gp = new GridPane();
		gp.setAlignment(Pos.CENTER);
		gp.setPadding(new Insets(11.5, 12.5, 13.5, 14.5));
		gp.setHgap(10);
		gp.setVgap(10);
		gp.add(new Label("First name: "), 4, 10);
		gp.add(new Label("Last name: "), 4, 11);
		gp.add(tfFirstName, 5, 10);
		gp.add(tfLastName, 5, 11);
		Button deleteperson = new Button("Delete");
		deleteperson.setOnAction(e -> {
			try {
				String fname = tfFirstName.getText();
				String lname = tfLastName.getText();
			    String n = "";
			    
			    Database d = new Database();
				for (int i = 0; i < db.size(); i++) {
					if (fname.equalsIgnoreCase(db.get(i).getFirstName()) && lname.equalsIgnoreCase(db.get(i).getLastName())) {
						
					}
					else {
						d.add(db.get(i));
					}
				}
				db = d;
				setListView();
				}catch(Exception E) {
					errorMessage();
				}
		});
		gp.add(deleteperson, 5, 12);
		Image deletepic = new Image("Pics/deleteperson.jpg");
		ImageView delete = new ImageView(deletepic);
		delete.setTranslateX(100);
		delete.setTranslateY(300);
		super.getChildren().addAll(gp, delete);
	}
	
	public void addStudent() {
		String fname = tfFirstName.getText();
		String lname = tfLastName.getText();
		String email = tfEmail.getText();
		String[] address = tfAddress.getText().split(" ");
		String street = "";
		int stNumber = Integer.parseInt(address[0]);
		for (int i = 0; i < address.length; i++) 
			street = address[i] + " ";
		String appt = tfAppt.getText();
		String city = tfCity.getText();
		String state = tfState.getText();
		String zipcode = tfZCode.getText();
		String phone = tfPhone.getText();
		String ptype = tfPType.getText();
		String classStanding = tfClassStanding.getText();
		String gpa = tfGpa.getText();
		
		try {
		FileWriter fw = new FileWriter(choosenFile, true);
		BufferedWriter keep = new BufferedWriter(fw);
		PrintWriter pw = new PrintWriter(keep);
		pw.println("Student," + fname + "," + lname + "," + email + "," + classStanding + "," + gpa);
		if(appt.length() == 0) {
			pw.println("Address," + stNumber + "," + street + "," + city + "," + state + "," + zipcode);
		} 
		else {
			pw.println("Address," + stNumber  + "," + appt + "," + street + "," + city + "," + state + "," + zipcode);
		}
		pw.println("Phone," + ptype + "," + phone);
		pw.flush();
		}catch(Exception e) {
			errorMessage();
		}
		
		
	}
	
	public void addStaff() {
		String fname = tfFirstName.getText();
		String lname = tfLastName.getText();
		String email = tfEmail.getText();
		String[] address = tfAddress.getText().split(" ");
		String street = "";
		int stNumber = Integer.parseInt(address[0]);
		for (int i = 0; i < address.length; i++) 
			street = address[i] + " ";
		String appt = tfAppt.getText();
		String city = tfCity.getText();
		String state = tfState.getText();
		String zipcode = tfZCode.getText();
		String phone = tfPhone.getText();
		String ptype = tfPType.getText();
		String officelocation = tfOLocation.getText();
		String salary = tfSalary.getText();
		String jobtitle = tfJTitle.getText();
		
		try {
		FileWriter fstream = new FileWriter(choosenFile, true);
		BufferedWriter bf = new BufferedWriter(fstream);
		PrintWriter out = new PrintWriter(bf);
		out.println("Staff," + fname + "," + lname + "," + email + "," + officelocation + "," + salary + "," + jobtitle);
		if(appt.length() == 0) {
			out.println("Address," + stNumber + "," + street + "," + city + "," + state + "," + zipcode);
		} 
		else {
			out.println("Address," + stNumber  + "," + appt + "," + street + "," + city + "," + state + "," + zipcode);
		}
		out.println("Phone," + ptype + "," + phone);
		out.flush();
		}catch(Exception e) {
			errorMessage();
		}
	}
	
	
	
	public Database getDatabase() {
		return this.db;
	}
	
	public void addFaculty() {
		String fname = tfFirstName.getText();
		String lname = tfLastName.getText();
		String email = tfEmail.getText();
		String[] address = tfAddress.getText().split(" ");
		String street = "";
		int stNumber = Integer.parseInt(address[0]);
		for (int i = 0; i < address.length; i++) 
			street = address[i] + " ";
		String appt = tfAppt.getText();
		String city = tfCity.getText();
		String state = tfState.getText();
		String zipcode = tfZCode.getText();
		String phone = tfPhone.getText();
		String ptype = tfPType.getText();
		String officelocation = tfOLocation.getText();
		String salary = tfSalary.getText();
		String officehours = tfOHours.getText();
		String rank = tfRank.getText();
		
		try {
		FileWriter fstream = new FileWriter(choosenFile, true);
		BufferedWriter bf = new BufferedWriter(fstream);
		PrintWriter out = new PrintWriter(bf);
		out.println("Faculty," + fname + "," + lname + "," + email + "," + officelocation + "," + salary + "," + officehours + "," + rank);
		if(appt.length() == 0) {
			out.println("Address," + stNumber + "," + street + "," + city + "," + state + "," + zipcode);
		} 
		else {
			out.println("Address," + stNumber  + "," + appt + "," + street + "," + city + "," + state + "," + zipcode);
		}
		out.println("Phone," + ptype + "," + phone);
		out.flush();
		}catch(Exception e) {
			errorMessage();
		}
	}
	
	public void errorMessage () {
		Stage stage = new Stage();
		Pane error = new Pane();
		Scene e = new Scene(error, 200, 200);
		Image errorpic = new Image("Pics/errorpic.png");
		ImageView epic = new ImageView(errorpic);
		error.getChildren().addAll(epic);
		stage.setScene(e);
		stage.show();
	}
	
	public void checkPhone (String number) throws PhoneNumberFormatException {
	
		if (number.length()==11 && Character.isDigit(number.charAt(0)) && 
				Character.isDigit(number.charAt(1))
				&& Character.isDigit(number.charAt(2)) && number.charAt(3)=='-' && 
				Character.isDigit(number.charAt(4)) && Character.isDigit(number.charAt(5)) && 
				Character.isDigit(number.charAt(6)) &&
				number.charAt(7)=='-' && Character.isDigit(number.charAt(8)) && 
				Character.isDigit(number.charAt(9)) && Character.isDigit(number.charAt(10)) 
				&& Character.isDigit(number.charAt(11))) {
			System.out.print("Correct");
		}else {
			errorMessage();
		}
	}
	
	

}
