package Project_Refactoring;


import java.io.File;

import Project_Refactoring.ButtonPanel;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class MainFrame extends Application{
	@Override
	public void start(Stage primaryStage) throws Exception {
		
		BorderPane mainPane = new BorderPane();
		TopPanel topPanel = new TopPanel();
		CenterPane centerPanel = new CenterPane(primaryStage);
		ButtonPanel buttonPanel = new ButtonPanel(centerPanel, primaryStage);		
		mainPane.setBottom(buttonPanel);
		mainPane.setTop(topPanel);
		mainPane.setCenter(centerPanel);
		primaryStage.setTitle("MainFrame");
		primaryStage.setScene(new Scene(mainPane,  375, 705));
		primaryStage.show(); 
		primaryStage.setResizable(false);
	}
	
	
	public static void main (String[] args) {
		Application.launch(args);
	}

}
