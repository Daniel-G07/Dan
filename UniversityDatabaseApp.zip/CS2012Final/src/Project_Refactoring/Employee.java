package Project_Refactoring;


import java.util.ArrayList;

public class Employee extends Person{
	private String officeLocation;
	private double salary;
	
	public Employee (String firstName, String lastName, String emailAddress, Address address,
			ArrayList<PhoneNumber>phoneNumbers, String officeLocation, double salary) {
		super(firstName, lastName, emailAddress, address, phoneNumbers);
		this.officeLocation = officeLocation;
		this.salary = salary;
	}

	public String getOfficeLocation() {
		return officeLocation;
	}

	public double getSalary() {
		return salary;
	}
	
	@Override
	public String toString () {
		String result = "";
		result += super.toString() + "\nOffice Location:  " + this.officeLocation + "\nSalary:\t\t  " + this.salary + "\n" ;
		return result;
	}
	
	public boolean equals(Object o) { 
		if (!(o instanceof Employee)) {
		return false;
		}
		else {
			Employee eq = (Employee)o;
			return super.equals(o)&& this.officeLocation.equalsIgnoreCase(eq.officeLocation) &&
					this.salary == (eq.salary);
		}
	}

}