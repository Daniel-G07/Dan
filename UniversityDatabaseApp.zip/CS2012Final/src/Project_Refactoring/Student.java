package Project_Refactoring;


import java.util.ArrayList;

public class Student extends Person {
	
	private String classStanding;
	private double gpa;
	
	
	public Student (String firstName, String lastName, String emailAddress, Address address,
			ArrayList<PhoneNumber>phoneNumbers, String classStanding, double gpa) {
		super(firstName,lastName,emailAddress,address,phoneNumbers);
		this.classStanding = classStanding;
		this.gpa = gpa;
		
	}

	public String getClassStanding() {
		return this.classStanding;
	}
	
	public double getGpa () {
		return this.gpa;
	}
	
	@Override
	public String toString() {
			return super.toString() + "\nClass Standing:   " + this.classStanding + "\nGPA:\t\t  " + this.gpa + "\n"
					+ "---------------------------------------------------------------\n";
	}
	
	public boolean equals(Object o) { 
		if (!(o instanceof Student)) {
		return false;
		}
		else {
			Student eq = (Student)o;
			return super.equals(o)&& this.classStanding.equalsIgnoreCase(eq.classStanding) &&
					this.gpa == (eq.gpa);
		}
	}
}