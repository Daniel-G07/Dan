package Project_Refactoring;

import java.util.regex.*;
import java.util.Scanner;

public class PhoneNumberFormatException extends Exception {
	private String numbers;
	public PhoneNumberFormatException (String numbers) {
		super(numbers);
		
	}
	
	public String getNumber() {
		return numbers;
	}
	
}
