package Project_Refactoring;

import java.util.ArrayList;

public class Staff extends Employee{

	private String jobTitle;
	
	
	public Staff (String firstName, String lastName, String emailAddress, Address address,
			ArrayList<PhoneNumber> phoneNumbers, String officeLocation, double salary,
			String jobTitle) {
		super(firstName, lastName, emailAddress, address, phoneNumbers,officeLocation,salary);
		this.jobTitle = jobTitle;
	}

	public String getJobTitle() {
		return jobTitle;
	}
	
	@Override
	public String toString() {
			String result = "";
			result += super.toString() + "\nJob Title:\t  " + this.jobTitle + "\n" + 
			"---------------------------------------------------------------\n";
			return result;
	}
	
	public boolean equals(Object o) { 
		if (!(o instanceof Staff)) {
		return false;
		}
		else {
			Staff eq = (Staff)o;
			return super.equals(o)&& this.jobTitle.equalsIgnoreCase(eq.jobTitle);
		}
	}
}
