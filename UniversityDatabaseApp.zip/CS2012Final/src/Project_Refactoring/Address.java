package Project_Refactoring;

public class Address {

	private int streetNumber;
	private String apartmentNumber;
	private String streetName;
	private String city;
	private String state;
	private int zipCode;
	
	public Address (int streetNumber, String streetName, String city, String state, int zipCode) {
		this.streetNumber = streetNumber;
		this.streetName = streetName;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
	}
	
	public Address (int streetNumber, String apartmentNumber, String streetName, String city,
			String state, int zipCode) {
		this.streetNumber = streetNumber;
		this.apartmentNumber = apartmentNumber;
		this.streetName = streetName;
		this.city = city;
		this.state = state;
		this.zipCode = zipCode;
	}

	public int getStreetNumber() {
		return this.streetNumber;
	}

	public String getApartmentNumber() {
		return this.apartmentNumber;
	}

	public String getStreetName() {
		return this.streetName;
	}

	public String getCity() {
		return this.city;
	}

	public String getState() {
		return this.state;
	}

	public int getZipCode() {
		return this.zipCode;
	}
	
	public String toString() {
		return  "\t  " + this.streetNumber + " " + this.streetName + "\n\t\t\t  " + this.city + 
				", " + this.state + ", " + this.zipCode;
	}
	
	public boolean equals(Object o) { 
		if (!(o instanceof Address)) {
		return false;
		}
		else {
			Address eq = (Address)o;
			return super.equals(o) && this.streetNumber == (eq.streetNumber) && 
					this.apartmentNumber == (eq.apartmentNumber) && 
					this.streetName.equalsIgnoreCase(eq.streetName) &&
					this.city.equalsIgnoreCase(eq.city) && this.state.equalsIgnoreCase(eq.state) &&
					this.state.equalsIgnoreCase(eq.state) && this.zipCode == (eq.zipCode);
		}
	}
	
	
}
