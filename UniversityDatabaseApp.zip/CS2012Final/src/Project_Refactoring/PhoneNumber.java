package Project_Refactoring;

public class PhoneNumber {
	private String type;
	private int areaCode;
	private int prefix;
	private int suffix;
	
	public PhoneNumber (String type, int areaCode, int prefix, int suffix) {
		this.type = type;
		this.areaCode = areaCode;
		this.prefix = prefix;
		this.suffix = suffix;
	}

	public String getType() {
		return type;
	}


	public int getAreaCode() {
		return areaCode;
	}

	public int getPrefix() {
		return prefix;
	}


	public int getSuffix() {
		return suffix;
	}
	
	@Override
	public String toString () {
		String result = "";
		 result+=this.type +": " + "(" + this.areaCode +") "  + this.prefix +
				"-" + this.suffix + "\n"; 
		 return result;
	}
	
	public boolean equals(Object o) { 
		if (!(o instanceof PhoneNumber)) {
		return false;
		}
		else {
			PhoneNumber eq = (PhoneNumber)o;
			return super.equals(o)&& this.type.equalsIgnoreCase(eq.type) &&
					this.areaCode == (eq.areaCode) && this.prefix == (eq.prefix) &&
					this.prefix == (eq.prefix) && this.suffix == (eq.suffix);
		}
	}
	

}